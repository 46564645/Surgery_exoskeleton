		#include<reg52.h>
		#include<intrins.h>
		#define uchar unsigned char
		#define uint unsigned int
  
		/********************************************************
		//Ӳ��������
		********************************************************/
		
		sbit RS = P3^1;
		sbit RW = P3^6;
		sbit EN = P3^7;

		/**********************************************************
		**********************************************************/

		void delay(uint t)
		{
			uchar i,j;
			do {
			    j=2;
			    do {
				i=165;
				do {
				    _nop_();
				    
				    } while(--i); 
				
				} while(--j);
			   
			  }while(--t);
		}
		
		bit lcdBusy()
		{
			bit BusyFlag;
			RS=0;
			RW=1;
			EN=1;
			_nop_();_nop_();_nop_();_nop_();
			BusyFlag = (bit)(P0&0x80);
			EN=0;
			return BusyFlag;

		}
		
		void writeCommand(uchar cmd)
		{
			delay(1);
		 	RS=0;
		 	RW=0;
		 	EN=1;
		 	P0=cmd;  //Һ��������P0
		 	EN=0;
		}

		void writeData(uchar date)
		{
			delay(1);
			 RS=1;
			 RW=0; 
			 EN=1;
			 P0=date; 
			 EN=0;
		
		}

		void lcdSet()
		{
			 writeCommand(0x30); //����ָ�
			 writeCommand(0x01); //������DDRAM�ĵ�ַ����
			 writeCommand(0x02); //��ַ��λ
			 writeCommand(0x0c); //��ʾ�������أ����׹� 
			 writeCommand(0x06); //DDRAM��ַ��1

		}

		void display(uchar y, uchar x, uchar *p) 
		{ 
			switch (y)
			{ 
			   case 1:writeCommand(0x7f+x); break; //Һ����һ��
			   case 2:writeCommand(0x8f+x); break; //0x90+(x-1)
			   case 3:writeCommand(0x87+x);break;
			   case 4:writeCommand(0x97+x);break;
			   default:break;
			}
			while(*p) 		 
			writeData(*p++); 
		}
