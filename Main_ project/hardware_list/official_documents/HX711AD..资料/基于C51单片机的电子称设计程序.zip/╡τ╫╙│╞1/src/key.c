		#include<reg52.h>
		#define uchar unsigned char
		extern void delay(uint);
		
		uchar keyscan()
		{
			uchar rcode,ccode;
			P1=0xf0;
			if((P1&0xf0)!=0xf0)
			{
				delay(20);
				if((P1&0xf0)!=0xf0)
				{
					rcode=0xfe;
					while((rcode&0x10)!=0)
					{
						P1=rcode;
						if((P1&0xf0)!=0xf0)
						{
							ccode=((P1&0xf0)|0x0f);
							do{;} while((P1&0xf0)!=0xf0);
							return ((~rcode)+(~ccode));
						}
						else
						{
							 rcode=(rcode<<1)|0x01;
						}
					}
									
				}
			}
			else
			{
				 return 0; // �޼����£�����ֵΪ0
			}			
	   }

